# 📱 Jak zainstalować Deutsch Lernen na telefonie

## 🎯 Metoda 1: Bezpośrednia instalacja (najłatwiejsza)

### Android (Chrome):
1. Otwórz aplikację w Chrome na telefonie
2. Poczekaj 3 sekundy - pojawi się przycisk **"📱 Zainstaluj aplikację!"**
3. Kliknij **"Instaluj"**
4. Gotowe! Ikona pojawi się na ekranie głównym

### iPhone/iPad (Safari):
1. Otwórz aplikację w Safari
2. Kliknij ikonę **"Udostępnij"** (kwadrat ze strzałką w górę)
3. Przewiń w dół i wybierz **"Dodaj do ekranu początkowego"**
4. Nazwij aplikację i kliknij **"Dodaj"**
5. Gotowe!

---

## 🖥️ Metoda 2: Hosting na serwerze (zalecana)

### Opcja A: GitHub Pages (darmowe)
1. Załóż konto na github.com
2. Stwórz nowe repozytorium o nazwie np. "deutsch-lernen"
3. Wgraj wszystkie pliki aplikacji
4. Wejdź w Settings → Pages → wybierz "main" branch
5. Twoja aplikacja będzie dostępna pod adresem: `https://twojanazwa.github.io/deutsch-lernen`

### Opcja B: Netlify (darmowe)
1. Wejdź na netlify.com
2. Przeciągnij folder z aplikacją na stronę
3. Gotowe! Dostaniesz link do aplikacji

### Opcja C: Lokalny serwer
Jeśli masz zainstalowany Python:
```
cd folder-z-aplikacja
python -m http.server 8000
```
Otwórz: http://localhost:8000

---

## 🖼️ Generowanie ikon

### Krok 1: Otwórz generator
1. Otwórz plik `generate-icons.html` w przeglądarce
2. Zobaczysz wszystkie ikony w różnych rozmiarach

### Krok 2: Pobierz ikony
1. Kliknij link **"📥 icon-XX.png"** pod każdą ikoną
2. Zapisz wszystkie ikony w folderze `icons/`

### Potrzebne ikony:
- icon-72.png
- icon-96.png
- icon-128.png
- icon-144.png
- icon-152.png
- icon-192.png
- icon-384.png
- icon-512.png

---

## 📁 Struktura folderów

```
deutsch-app/
├── index.html          ← Główna strona
├── app.js              ← Logika aplikacji
├── style.css           ← Style
├── words.js            ← Baza słówek
├── manifest.json       ← Konfiguracja PWA
├── sw.js               ← Service Worker (offline)
├── generate-icons.html ← Generator ikon
└── icons/
    ├── icon.svg        ← Ikona wektorowa
    ├── icon-72.png
    ├── icon-96.png
    ├── icon-128.png
    ├── icon-144.png
    ├── icon-152.png
    ├── icon-192.png
    ├── icon-384.png
    └── icon-512.png
```

---

## ✅ Funkcje PWA

Po zainstalowaniu aplikacja będzie:
- ✅ Działać offline (bez internetu)
- ✅ Mieć ikonę na ekranie głównym
- ✅ Otwierać się na pełnym ekranie
- ✅ Zapisywać postępy lokalnie
- ✅ Działać jak natywna aplikacja

---

## ❓ Problemy?

### Aplikacja nie instaluje się:
- Upewnij się, że otwierasz przez HTTPS lub localhost
- Wyczyść cache przeglądarki
- Sprawdź czy wszystkie pliki są w jednym folderze

### Ikony nie wyświetlają się:
- Upewnij się, że ikony są w folderze `icons/`
- Sprawdź nazwy plików (małe litery!)

### Offline nie działa:
- Odśwież stronę kilka razy
- Zamknij i otwórz ponownie
- Sprawdź czy sw.js jest w głównym folderze

---

## 📧 Potrzebujesz pomocy?

Napisz mi w czacie, pomogę! 😊
